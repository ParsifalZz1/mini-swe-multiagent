from query_parser import parse_query


def test_parse_query_basic_pairs():
    assert parse_query("name=alice&role=admin") == {"name": "alice", "role": "admin"}


def test_parse_query_ignores_empty_segments():
    assert parse_query("name=alice&&role=admin&") == {"name": "alice", "role": "admin"}


def test_parse_query_preserves_values_with_equals():
    assert parse_query("token=a=b=c") == {"token": "a=b=c"}
