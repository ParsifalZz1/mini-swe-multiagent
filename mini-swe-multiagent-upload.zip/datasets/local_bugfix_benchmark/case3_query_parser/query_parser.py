def parse_query(query):
    pairs = query.split("&")
    result = {}
    for pair in pairs:
        key, value = pair.split("=")
        result[key] = value
    return result
