def normalize_username(value):
    return value.lower()


def title_case_words(value):
    return " ".join(part.capitalize() for part in value.split())
