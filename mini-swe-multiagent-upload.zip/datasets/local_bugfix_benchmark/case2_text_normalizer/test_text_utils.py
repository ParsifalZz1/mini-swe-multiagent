from text_utils import normalize_username, title_case_words


def test_normalize_username_trims_and_lowercases():
    assert normalize_username(" Alice ") == "alice"
    assert normalize_username("\tBOB\n") == "bob"


def test_title_case_words():
    assert title_case_words("hello   world") == "Hello World"
