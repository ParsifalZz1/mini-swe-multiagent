from datetime import date

from date_range import days_between, is_within_range


def test_is_within_range_inclusive():
    start = date(2026, 1, 1)
    end = date(2026, 1, 31)
    assert is_within_range(date(2026, 1, 1), start, end)
    assert is_within_range(date(2026, 1, 15), start, end)
    assert is_within_range(date(2026, 1, 31), start, end)
    assert not is_within_range(date(2025, 12, 31), start, end)


def test_days_between():
    assert days_between(date(2026, 1, 1), date(2026, 1, 3)) == 2
