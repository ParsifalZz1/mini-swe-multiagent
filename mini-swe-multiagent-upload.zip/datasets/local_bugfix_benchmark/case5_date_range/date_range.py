from datetime import date


def is_within_range(value, start, end):
    return start < value < end


def days_between(start, end):
    return (end - start).days
