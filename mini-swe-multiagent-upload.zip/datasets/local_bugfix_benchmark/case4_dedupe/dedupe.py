def unique_preserve_order(items):
    return sorted(set(items))


def count_items(items):
    counts = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return counts
