from dedupe import count_items, unique_preserve_order


def test_unique_preserve_order():
    assert unique_preserve_order(["b", "a", "b", "c", "a"]) == ["b", "a", "c"]


def test_count_items():
    assert count_items(["a", "b", "a"]) == {"a": 2, "b": 1}
