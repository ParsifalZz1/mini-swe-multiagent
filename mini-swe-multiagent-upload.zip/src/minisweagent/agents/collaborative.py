"""Planner-Coder-Reviewer collaboration agent.

This agent keeps mini-SWE-agent's execution model intact: only the coder
executes bash actions. The planner and reviewer are additional model calls that
inject structured guidance into the same linear message history.
"""

import time
from typing import Literal

from pydantic import BaseModel

from minisweagent.agents.default import AgentConfig, DefaultAgent
from minisweagent.exceptions import InterruptAgentFlow
from minisweagent.models.utils.content_string import get_content_string


class CollaborativeAgentConfig(AgentConfig):
    planner_system_template: str
    """System prompt used for the planner role."""
    planner_instance_template: str
    """User prompt used for the first planner call."""
    reviewer_system_template: str
    """System prompt used for the reviewer role."""
    reviewer_instance_template: str
    """User prompt used for reviewer calls."""
    planner_mode: Literal["once", "every_step", "off"] = "once"
    """When to call the planner."""
    reviewer_mode: Literal["every_step", "off"] = "every_step"
    """When to call the reviewer after coder actions."""
    review_feedback_template: str = (
        "Reviewer feedback for the next coding step:\n\n{{review}}\n\n"
        "Use this feedback to revise the implementation if needed. If the reviewer says ACCEPT and the task is complete, submit."
    )
    """Message injected into the coder context after each review."""


class CollaborativeAgent(DefaultAgent):
    """A light-weight multi-agent scaffold with Planner, Coder, and Reviewer roles."""

    def __init__(self, *args, config_class: type[BaseModel] = CollaborativeAgentConfig, **kwargs):
        super().__init__(*args, config_class=config_class, **kwargs)
        self.collaboration_events: list[dict] = []

    def run(self, task: str = "", **kwargs) -> dict:
        """Run a Planner-Coder-Reviewer workflow until the coder exits."""
        self.extra_template_vars |= {"task": task, **kwargs}
        self.messages = []
        self.collaboration_events = []
        self.add_messages(
            self.model.format_message(role="system", content=self._render_template(self.config.system_template)),
            self.model.format_message(role="user", content=self._render_template(self.config.instance_template)),
        )
        if self.config.planner_mode != "off":
            self._run_planner(reason="initial")
        while True:
            try:
                self.step()
            except InterruptAgentFlow as e:
                self.add_messages(*e.messages)
            except Exception as e:
                self.handle_uncaught_exception(e)
                raise
            finally:
                self.save(self.config.output_path)
            if self.messages[-1].get("role") == "exit":
                break
        return self.messages[-1].get("extra", {})

    def step(self) -> list[dict]:
        """Run one coder action step, followed by optional reviewer feedback."""
        if self.config.planner_mode == "every_step" and self.n_calls > 0:
            self._run_planner(reason="refresh")
        result = super().step()
        if self.messages[-1].get("role") == "exit":
            return result
        if self.config.reviewer_mode != "off":
            self._run_reviewer()
        return result

    def get_template_vars(self, **kwargs) -> dict:
        return super().get_template_vars(messages=self._format_shared_messages(), **kwargs)

    def _run_planner(self, *, reason: str) -> dict:
        message = self._query_collaborator(
            role_name="planner",
            system_template=self.config.planner_system_template,
            instance_template=self.config.planner_instance_template,
            reason=reason,
        )
        self._inject_collaboration_message("planner", message)
        return message

    def _run_reviewer(self) -> dict:
        message = self._query_collaborator(
            role_name="reviewer",
            system_template=self.config.reviewer_system_template,
            instance_template=self.config.reviewer_instance_template,
            reason="post_step_review",
        )
        self._inject_collaboration_message("reviewer", message)
        return message

    def _query_collaborator(
        self,
        *,
        role_name: str,
        system_template: str,
        instance_template: str,
        reason: str,
    ) -> dict:
        if 0 < self.config.step_limit <= self.n_calls or 0 < self.config.cost_limit <= self.cost:
            return self.model.format_message(
                role="user",
                content=f"{role_name.title()} skipped because the shared call or cost limit was reached.",
                extra={"collaboration": {"role": role_name, "reason": reason, "skipped": True}},
            )
        self.n_calls += 1
        messages = [
            self.model.format_message(role="system", content=self._render_template(system_template)),
            self.model.format_message(role="user", content=self._render_template(instance_template)),
        ]
        response = self._query_text_only(messages)
        self.cost += response.get("extra", {}).get("cost", 0.0)
        response.setdefault("extra", {})["actions"] = []
        event = {
            "role": role_name,
            "reason": reason,
            "content": get_content_string(response),
            "timestamp": time.time(),
        }
        self.collaboration_events.append(event)
        response["extra"]["collaboration"] = event
        return response

    def _inject_collaboration_message(self, role_name: str, collaborator_message: dict) -> list[dict]:
        content = get_content_string(collaborator_message)
        if role_name == "planner":
            prompt = f"Planner guidance for the coding agent:\n\n{content}"
        else:
            prompt = self._render_inline_review_feedback(content)
        return self.add_messages(
            self.model.format_message(
                role="user",
                content=prompt,
                extra={
                    "collaboration": {
                        "role": role_name,
                        "source_message": collaborator_message,
                        "timestamp": time.time(),
                    }
                },
            )
        )

    def _render_inline_review_feedback(self, review: str) -> str:
        return self.config.review_feedback_template.replace("{{review}}", review)

    def _query_text_only(self, messages: list[dict]) -> dict:
        if hasattr(self.model, "_query") and hasattr(self.model, "_prepare_messages_for_api"):
            response = self.model._query(self.model._prepare_messages_for_api(messages), tool_choice="none")
            message = response.choices[0].message.model_dump()
            message["extra"] = {
                "actions": [],
                "response": response.model_dump(),
                "cost": self.model._calculate_cost(response)["cost"],
                "timestamp": time.time(),
            }
            return message
        message = self.model.query(messages)
        message.setdefault("extra", {})["actions"] = []
        return message

    def _format_shared_messages(self) -> str:
        lines = []
        for idx, message in enumerate(self.messages[-12:], start=max(1, len(self.messages) - 11)):
            role = message.get("role") or message.get("type", "unknown")
            content = get_content_string(message)
            if len(content) > 4000:
                content = content[:2000] + "\n...[truncated]...\n" + content[-2000:]
            if content:
                lines.append(f"[{idx}] {role}:\n{content}")
        return "\n\n".join(lines)

    def serialize(self, *extra_dicts) -> dict:
        return super().serialize({"info": {"collaboration_events": self.collaboration_events}}, *extra_dicts)
