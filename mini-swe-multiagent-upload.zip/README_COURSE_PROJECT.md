# 基于模型协作的轻量级软件工程 Agent 改造

## 项目简介

本项目基于开源项目 mini-swe-agent 进行二次改造，面向“高级软件工程”课程大作业，研究如何在软件工程自动化任务中引入模型协作机制。原项目提供了一个极简的软件工程智能体：模型根据问题描述生成命令，环境执行命令并返回观察结果，直到模型提交最终补丁或完成任务。本项目在不破坏原有单智能体基线的前提下，新增 Planner-Coder-Reviewer 三角色协作流程，用于完成代码缺陷定位、修复和验证任务。

## 主要改造

- 新增 `CollaborativeAgent`，实现 Planner、Coder、Reviewer 三角色协作。
- Planner 负责阅读任务并给出定位计划、复现策略和修复建议。
- Coder 复用 mini-swe-agent 原有命令执行循环，是唯一允许执行命令和修改文件的角色。
- Reviewer 在每轮 Coder 行动后进行审查，给出 ACCEPT 或 REVISE 反馈。
- 增加纯文本协作者调用路径，避免 Planner/Reviewer 误触发工具调用导致角色边界混乱。
- 增加 OpenAI-compatible 网关配置和非交互运行脚本，便于通过 API 运行实验。
- 构造 5 个本地 pytest 缺陷修复示例作为小型实验数据集。

## 数据集

数据集位于：

```text
datasets/local_bugfix_benchmark
```

包含 5 个小型 Python 缺陷修复任务：

| Case | 缺陷类型 | 判定方式 |
|---|---|---|
| `case1_calculator` | 加法函数错误实现为减法 | pytest |
| `case2_text_normalizer` | 用户名规范化未去除空白字符 | pytest |
| `case3_query_parser` | 查询字符串解析不能处理空段和等号 | pytest |
| `case4_dedupe` | 去重函数破坏原始顺序 | pytest |
| `case5_date_range` | 日期区间判断未包含边界 | pytest |

这些示例作为本项目的数据集使用。每个 case 都包含一个带缺陷的源码文件和对应测试文件，智能体需要修改源码并让测试通过。

## 运行环境

建议使用 Python 3.10 及以上版本。本项目实验使用项目内虚拟环境 `.venv`。

安装依赖：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -U pip
.\.venv\Scripts\python.exe -m pip install -e .
.\.venv\Scripts\python.exe -m pip install pytest
```

设置 API key：

```powershell
$env:OPENAI_API_KEY="your-api-key"
$env:PYTHONPATH="src"
$env:MSWEA_SILENT_STARTUP="1"
$env:PYTHONIOENCODING="utf-8"
```

API key 不应写入代码、配置文件或实验结果文件。

## 单个任务运行

Baseline 单智能体：

```powershell
.\.venv\Scripts\python.exe scripts\run_noninteractive.py -c mini.yaml -c fhl_codex_spark.yaml -c agent.agent_class=default -c "environment.cwd=datasets\local_bugfix_benchmark\case1_calculator" -t "Fix the bug so that all pytest tests pass. Keep the change minimal." -o outputs\case1-baseline.traj.json
```

协作智能体：

```powershell
.\.venv\Scripts\python.exe scripts\run_noninteractive.py -c collaborative.yaml -c fhl_codex_spark.yaml -c "environment.cwd=datasets\local_bugfix_benchmark\case1_calculator" -t "Fix the bug so that all pytest tests pass. Keep the change minimal." -o outputs\case1-collaborative.traj.json
```

## 批量实验

运行 5 个 case 的 baseline 与 collaborative 对照实验：

```powershell
.\.venv\Scripts\python.exe scripts\run_local_benchmark.py
```

生成结果：

```text
outputs/fhl_5case_experiment_summary.csv
outputs/fhl_5case_method_summary.csv
```

## 实验结果摘要

| 方法 | Case 数 | 成功率 | 平均 API 调用数 | 平均消息数 | 平均协作事件数 |
|---|---:|---:|---:|---:|---:|
| baseline | 5 | 100% | 10.80 | 24.20 | 0.00 |
| collaborative | 5 | 100% | 20.20 | 32.00 | 9.80 |

协作方法在 5 个任务上与 baseline 一样全部修复成功。由于增加了 Planner 和 Reviewer，平均 API 调用数上升，但协作轨迹保留了计划、审查和修正依据，增强了过程可解释性。在 `case3_query_parser` 中，协作方法在成功修复的同时将消息数从 59 降低到 44，说明 Reviewer 反馈在较复杂任务中可能减少无效探索。

## 目录说明

```text
src/minisweagent/agents/collaborative.py              协作智能体实现
src/minisweagent/config/collaborative.yaml            本地协作配置
src/minisweagent/config/benchmarks/swebench_collaborative.yaml  SWE-bench 协作配置
scripts/run_noninteractive.py                         非交互运行入口
scripts/run_local_benchmark.py                        5 case 批量实验脚本
scripts/summarize_collaboration_runs.py               轨迹汇总脚本
datasets/local_bugfix_benchmark                       本项目实验数据集
outputs                                               实验轨迹和统计结果
```

## 说明

本项目的重点不是构造复杂前端或大规模 benchmark，而是在一个真实开源软件工程 agent 项目中加入模型协作机制，并通过可复现的小型缺陷修复数据集验证其效果。
