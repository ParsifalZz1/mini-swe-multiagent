from pathlib import Path

import yaml

from minisweagent.agents import get_agent_class
from minisweagent.agents.collaborative import CollaborativeAgent
from minisweagent.environments.local import LocalEnvironment
from minisweagent.models.test_models import DeterministicModel, make_output


def get_text(msg: dict) -> str:
    content = msg.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list) and content:
        return content[0].get("text", "")
    return ""


def test_collaborative_agent_is_registered():
    assert get_agent_class("collaborative") is CollaborativeAgent


def test_planner_and_reviewer_messages_are_injected(tmp_path):
    config = yaml.safe_load(Path("src/minisweagent/config/collaborative.yaml").read_text())["agent"]
    output_path = tmp_path / "collaborative.traj.json"
    model = DeterministicModel(
        outputs=[
            make_output("Inspect app.py, reproduce with a small script, then patch the parser.", []),
            make_output("I will inspect the repository.", [{"command": "echo inspected"}]),
            make_output("REVISE: run the focused regression test before submitting.", []),
            make_output(
                "The regression test passed, so I will submit.",
                [{"command": "echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT\necho done"}],
            ),
        ],
        cost_per_call=0.1,
    )
    agent = CollaborativeAgent(
        model,
        LocalEnvironment(),
        **{**config, "output_path": output_path, "cost_limit": 5.0},
    )

    info = agent.run("Fix the parser bug")

    assert info["exit_status"] == "Submitted"
    injected_messages = [msg for msg in agent.messages if msg.get("extra", {}).get("collaboration")]
    assert any("Planner guidance" in get_text(msg) for msg in injected_messages)
    assert any("Reviewer feedback" in get_text(msg) for msg in injected_messages)
    assert [event["role"] for event in agent.collaboration_events] == ["planner", "reviewer"]
    assert output_path.exists()


def test_reviewer_can_be_disabled():
    config = yaml.safe_load(Path("src/minisweagent/config/collaborative.yaml").read_text())["agent"]
    model = DeterministicModel(
        outputs=[
            make_output("Start with the failing test.", []),
            make_output(
                "No review needed; submit immediately.",
                [{"command": "echo COMPLETE_TASK_AND_SUBMIT_FINAL_OUTPUT\ndone"}],
            ),
        ],
        cost_per_call=0.1,
    )
    agent = CollaborativeAgent(
        model,
        LocalEnvironment(),
        **{**config, "reviewer_mode": "off", "cost_limit": 5.0},
    )

    info = agent.run("Finish quickly")

    assert info["exit_status"] == "Submitted"
    assert [event["role"] for event in agent.collaboration_events] == ["planner"]
