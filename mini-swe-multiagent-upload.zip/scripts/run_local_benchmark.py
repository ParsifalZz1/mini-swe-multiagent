"""Run the five local pytest bug-fix cases for baseline and collaborative agents."""

import csv
import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BENCH_ROOT = ROOT / "datasets" / "local_bugfix_benchmark"
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"

CASES = {
    "case1_calculator": {
        "file": "calculator.py",
        "buggy": 'def add_numbers(a, b):\n    return a - b\n\n\ndef multiply_numbers(a, b):\n    return a * b\n',
    },
    "case2_text_normalizer": {
        "file": "text_utils.py",
        "buggy": (
            'def normalize_username(value):\n    return value.lower()\n\n\n'
            'def title_case_words(value):\n    return " ".join(part.capitalize() for part in value.split())\n'
        ),
    },
    "case3_query_parser": {
        "file": "query_parser.py",
        "buggy": (
            'def parse_query(query):\n'
            '    pairs = query.split("&")\n'
            '    result = {}\n'
            '    for pair in pairs:\n'
            '        key, value = pair.split("=")\n'
            '        result[key] = value\n'
            '    return result\n'
        ),
    },
    "case4_dedupe": {
        "file": "dedupe.py",
        "buggy": (
            'def unique_preserve_order(items):\n    return sorted(set(items))\n\n\n'
            'def count_items(items):\n'
            '    counts = {}\n'
            '    for item in items:\n'
            '        counts[item] = counts.get(item, 0) + 1\n'
            '    return counts\n'
        ),
    },
    "case5_date_range": {
        "file": "date_range.py",
        "buggy": (
            'from datetime import date\n\n\n'
            'def is_within_range(value, start, end):\n    return start < value < end\n\n\n'
            'def days_between(start, end):\n    return (end - start).days\n'
        ),
    },
}

METHODS = {
    "baseline": ["-c", "mini.yaml", "-c", "fhl_codex_spark.yaml", "-c", "agent.agent_class=default"],
    "collaborative": ["-c", "collaborative.yaml", "-c", "fhl_codex_spark.yaml"],
}


def reset_case(case_name: str) -> None:
    spec = CASES[case_name]
    (BENCH_ROOT / case_name / spec["file"]).write_text(spec["buggy"], encoding="utf-8")


def run_command(args: list[str], *, timeout: int) -> subprocess.CompletedProcess:
    env = os.environ.copy()
    env["PYTHONPATH"] = "src"
    env["MSWEA_SILENT_STARTUP"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return subprocess.run(args, cwd=ROOT, text=True, encoding="utf-8", errors="replace", capture_output=True, env=env, timeout=timeout)


def summarize_traj(path: Path) -> dict:
    if not path.exists():
        return {"exit_status": "", "api_calls": "", "messages": "", "collaboration_events": "", "planner_calls": "", "reviewer_calls": ""}
    data = json.loads(path.read_text(encoding="utf-8"))
    events = data.get("info", {}).get("collaboration_events", [])
    return {
        "exit_status": data.get("info", {}).get("exit_status", ""),
        "api_calls": data.get("info", {}).get("model_stats", {}).get("api_calls", ""),
        "messages": len(data.get("messages", [])),
        "collaboration_events": len(events),
        "planner_calls": sum(1 for event in events if event.get("role") == "planner"),
        "reviewer_calls": sum(1 for event in events if event.get("role") == "reviewer"),
    }


def main() -> None:
    task = "Fix the bug so that all pytest tests pass. Keep the change minimal."
    outputs = ROOT / "outputs"
    outputs.mkdir(exist_ok=True)
    rows = []
    for case_name in CASES:
        case_dir = BENCH_ROOT / case_name
        for method, config_args in METHODS.items():
            reset_case(case_name)
            traj = outputs / f"fhl-{case_name}-{method}.traj.json"
            command = [
                str(PYTHON),
                "scripts/run_noninteractive.py",
                *config_args,
                "-c",
                f"environment.cwd={case_dir}",
                "-t",
                task,
                "-o",
                str(traj),
            ]
            try:
                run = run_command(command, timeout=480)
                run_returncode = run.returncode
                run_tail = (run.stdout + "\n" + run.stderr)[-1200:]
            except subprocess.TimeoutExpired as exc:
                run_returncode = 124
                run_tail = ((exc.stdout or "") + "\n" + (exc.stderr or ""))[-1200:]
            test = run_command([str(PYTHON), "-m", "pytest", str(case_dir), "-q"], timeout=120)
            row = {
                "case": case_name,
                "method": method,
                "run_returncode": run_returncode,
                "pytest_passed": int(test.returncode == 0),
                "pytest_output": (test.stdout + "\n" + test.stderr).strip().replace("\n", " | ")[:500],
                "run_tail": run_tail.replace("\n", " | ")[:500],
                "trajectory": str(traj),
                **summarize_traj(traj),
            }
            rows.append(row)
            print(json.dumps(row, ensure_ascii=False))
    out_csv = outputs / "fhl_5case_experiment_summary.csv"
    with out_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {out_csv}")


if __name__ == "__main__":
    main()
