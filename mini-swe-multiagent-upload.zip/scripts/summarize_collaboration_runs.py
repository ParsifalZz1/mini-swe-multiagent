"""Summarize baseline and collaborative mini-swe-agent trajectory files.

Example:
    python scripts/summarize_collaboration_runs.py --runs outputs/baseline outputs/collaborative
"""

import argparse
import csv
import json
from pathlib import Path


FIELDNAMES = [
    "file",
    "exit_status",
    "resolved",
    "api_calls",
    "cost",
    "collaboration_events",
    "planner_calls",
    "reviewer_calls",
    "messages",
]


def summarize_file(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    info = data.get("info", {})
    model_stats = info.get("model_stats", {})
    collaboration_events = info.get("collaboration_events", [])
    return {
        "file": str(path),
        "exit_status": info.get("exit_status", ""),
        "resolved": int(info.get("exit_status") == "Submitted"),
        "api_calls": model_stats.get("api_calls", 0),
        "cost": model_stats.get("instance_cost", 0.0),
        "collaboration_events": len(collaboration_events),
        "planner_calls": sum(1 for event in collaboration_events if event.get("role") == "planner"),
        "reviewer_calls": sum(1 for event in collaboration_events if event.get("role") == "reviewer"),
        "messages": len(data.get("messages", [])),
    }


def iter_trajectories(paths: list[Path]) -> list[Path]:
    files = []
    for path in paths:
        if path.is_dir():
            files.extend(sorted(path.glob("*.traj.json")))
            files.extend(sorted(path.glob("*.json")))
        else:
            files.append(path)
    return sorted(set(files))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs", nargs="+", type=Path, required=True, help="Trajectory files or directories")
    parser.add_argument("--output", type=Path, default=None, help="Optional CSV output path")
    args = parser.parse_args()

    rows = [summarize_file(path) for path in iter_trajectories(args.runs)]
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
            writer.writeheader()
            writer.writerows(rows)
    else:
        print(json.dumps(rows, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
