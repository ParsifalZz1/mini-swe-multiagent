import csv
import statistics
from pathlib import Path


root = Path(__file__).resolve().parents[1]
input_csv = root / "outputs" / "fhl_5case_experiment_summary.csv"
output_csv = root / "outputs" / "fhl_5case_method_summary.csv"

rows = list(csv.DictReader(input_csv.open(encoding="utf-8")))
summary_rows = []
for method in sorted({row["method"] for row in rows}):
    selected = [row for row in rows if row["method"] == method]
    summary_rows.append(
        {
            "method": method,
            "cases": len(selected),
            "success_rate": f"{sum(int(row['pytest_passed']) for row in selected) / len(selected):.2f}",
            "avg_api_calls": f"{statistics.mean(int(row['api_calls']) for row in selected):.2f}",
            "avg_messages": f"{statistics.mean(int(row['messages']) for row in selected):.2f}",
            "avg_collaboration_events": f"{statistics.mean(int(row['collaboration_events']) for row in selected):.2f}",
        }
    )

with output_csv.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0]))
    writer.writeheader()
    writer.writerows(summary_rows)

print(output_csv)
for row in summary_rows:
    print(row)
