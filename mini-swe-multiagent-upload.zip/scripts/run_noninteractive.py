"""Run mini-swe-agent from config files without importing the interactive CLI."""

import argparse
import os
from pathlib import Path

from minisweagent.agents import get_agent
from minisweagent.config import get_config_from_spec
from minisweagent.environments import get_environment
from minisweagent.models import get_model
from minisweagent.utils.serialize import recursive_merge


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", action="append", default=[], help="Config file, name, or key=value override")
    parser.add_argument("-t", "--task", required=True, help="Task/problem statement")
    parser.add_argument("-o", "--output", type=Path, default=None, help="Trajectory output file")
    parser.add_argument("--agent-default", default="default", help="Default agent type when config does not set one")
    args = parser.parse_args()

    os.environ.setdefault("MSWEA_SILENT_STARTUP", "1")
    configs = [get_config_from_spec(spec) for spec in args.config]
    if args.output:
        configs.append({"agent": {"output_path": args.output}})
    config = recursive_merge(*configs)

    model = get_model(config=config.get("model", {}))
    env = get_environment(config.get("environment", {}), default_type="local")
    agent = get_agent(model, env, config.get("agent", {}), default_type=args.agent_default)
    result = agent.run(args.task)
    print(result)


if __name__ == "__main__":
    main()
