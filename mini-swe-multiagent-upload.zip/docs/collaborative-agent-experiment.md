# Planner-Coder-Reviewer Collaboration Experiment

This project extension adds a `collaborative` agent type to mini-swe-agent.
The baseline remains the original single-agent workflow. The new workflow adds
two non-executing model roles:

- Planner: reads the issue and proposes an investigation and repair plan.
- Coder: reuses the original mini-swe-agent command execution loop.
- Reviewer: reviews the latest coder step and injects feedback before the next action.

## Running a Local Task

Baseline:

```bash
PYTHONPATH=src python -m minisweagent.run.mini -c mini.yaml -y -t "your task" -o outputs/baseline.traj.json
```

Collaborative:

```bash
PYTHONPATH=src python -m minisweagent.run.mini -c collaborative.yaml -y -t "your task" -o outputs/collaborative.traj.json
```

## Running One SWE-bench Instance

Baseline:

```bash
PYTHONPATH=src python -m minisweagent.run.benchmarks.swebench_single -c swebench.yaml -y -i 0 -o outputs/swebench-baseline.traj.json
```

Collaborative:

```bash
PYTHONPATH=src python -m minisweagent.run.benchmarks.swebench_single -c swebench.yaml -c swebench_collaborative.yaml -y -i 0 -o outputs/swebench-collaborative.traj.json
```

Set the model with `-m`, `MSWEA_MODEL_NAME`, or the global mini-swe-agent config.
API keys follow LiteLLM conventions, for example `OPENAI_API_KEY` or provider-specific keys.

## Alibaba Bailian / Qwen

Alibaba Bailian provides an OpenAI-compatible API. For the China/Beijing region,
use:

```powershell
$env:OPENAI_API_KEY="your-bailian-api-key"
```

The project includes a Qwen3.6 Flash config:

```bash
-c bailian_qwen36_flash.yaml
```

Baseline:

```powershell
python -m minisweagent.run.benchmarks.swebench_single -c swebench.yaml -c bailian_qwen36_flash.yaml -y -i 0 -o outputs\swebench-baseline-qwen.traj.json
```

Collaborative:

```powershell
python -m minisweagent.run.benchmarks.swebench_single -c swebench.yaml -c swebench_collaborative.yaml -c bailian_qwen36_flash.yaml -y -i 0 -o outputs\swebench-collaborative-qwen.traj.json
```

If your Bailian workspace is in another region, change the `api_base` value in
`src/minisweagent/config/bailian_qwen36_flash.yaml`.

## Suggested Small Experiment

Use 10 to 30 SWE-bench Lite or Verified instances.

- Baseline: original single-agent mini-swe-agent.
- Method: Planner-Coder-Reviewer collaborative agent.
- Metrics: resolved count, exit status, API calls, cost, number of planner/reviewer calls, and manual patch quality notes.
- Optional ablation: disable reviewer with `-c agent.reviewer_mode=off`.

Summarize trajectories:

```bash
python scripts/summarize_collaboration_runs.py --runs outputs --output outputs/summary.csv
```
